import React, { useEffect, useState } from 'react';
import {
  Box,
  IconButton,
  Badge,
  Menu,
  MenuItem,
  Divider,
  Typography,
  Chip,
  ListItemIcon,
} from '@mui/material';
import {
  Notifications,
  Circle,
  EmojiEvents,
  LocalFireDepartment,
  School,
  Star,
  Coffee,
} from '@mui/icons-material';
import { notificationAPI } from '../services/api';
import { Notification } from '../types';

const NotificationCenter: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const data = await notificationAPI.getNotifications();
      setNotifications(data);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: number) => {
    try {
      await notificationAPI.markAsRead(notificationId);
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      );
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'achievement':
        return <EmojiEvents color="warning" />;
      case 'streak':
        return <LocalFireDepartment color="error" />;
      case 'goal':
        return <School color="primary" />;
      case 'motivational':
        return <Star color="secondary" />;
      case 'break':
        return <Coffee color="info" />;
      default:
        return <Notifications color="action" />;
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'только что';
    if (diffInMinutes < 60) return `${diffInMinutes} мин назад`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} ч назад`;
    return `${Math.floor(diffInMinutes / 1440)} дн назад`;
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const open = Boolean(anchorEl);

  return (
    <Box>
      <IconButton
        color="inherit"
        onClick={handleClick}
        sx={{ ml: 1 }}
      >
        <Badge badgeContent={unreadCount} color="error">
          <Notifications />
        </Badge>
      </IconButton>
      
      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            width: 350,
            maxHeight: 400,
            overflow: 'visible',
            mt: 1.5,
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <Box sx={{ px: 2, py: 1 }}>
          <Typography variant="h6" gutterBottom>
            Уведомления
            {unreadCount > 0 && (
              <Chip 
                label={unreadCount} 
                size="small" 
                color="error" 
                sx={{ ml: 1 }}
              />
            )}
          </Typography>
        </Box>
        
        <Divider />
        
        {loading ? (
          <MenuItem>
            <Typography color="text.secondary">Загрузка...</Typography>
          </MenuItem>
        ) : notifications.length === 0 ? (
          <MenuItem>
            <Typography color="text.secondary">Нет уведомлений</Typography>
          </MenuItem>
        ) : (
          <Box sx={{ maxHeight: 300, overflow: 'auto' }}>
            {notifications.slice(0, 5).map((notification) => (
              <MenuItem
                key={notification.id}
                onClick={() => {
                  if (!notification.is_read) {
                    markAsRead(notification.id);
                  }
                }}
                sx={{
                  bgcolor: notification.is_read ? 'transparent' : 'action.hover',
                  '&:hover': {
                    bgcolor: 'action.selected',
                  },
                  py: 1.5,
                  px: 2,
                }}
              >
                <ListItemIcon sx={{ mr: 1 }}>
                  {getNotificationIcon(notification.type || notification.notification_type)}
                </ListItemIcon>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography 
                    variant="subtitle2" 
                    sx={{ 
                      fontWeight: notification.is_read ? 'normal' : 'bold',
                      mb: 0.5
                    }}
                  >
                    {notification.title}
                  </Typography>
                  <Typography 
                    variant="body2" 
                    color="text.secondary"
                    sx={{ 
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                      mb: 0.5
                    }}
                  >
                    {notification.message}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {formatTimeAgo(notification.created_at)}
                  </Typography>
                </Box>
                {!notification.is_read && (
                  <Circle color="primary" sx={{ fontSize: 8, ml: 1 }} />
                )}
              </MenuItem>
            ))}
          </Box>
        )}
        
        {notifications.length > 5 && (
          <>
            <Divider />
            <MenuItem onClick={handleClose}>
              <Typography 
                variant="body2" 
                color="primary" 
                sx={{ textAlign: 'center', width: '100%' }}
              >
                Показать все уведомления
              </Typography>
            </MenuItem>
          </>
        )}
      </Menu>
    </Box>
  );
};

export default NotificationCenter;