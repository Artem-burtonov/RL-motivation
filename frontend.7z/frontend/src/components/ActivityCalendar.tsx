import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Tooltip,
  Paper,
  Chip,
  Fade,
  Zoom,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  LocalFireDepartment,
  CheckCircle,
  CalendarToday,
  TrendingUp,
  EmojiEvents,
  Insights,
} from '@mui/icons-material';

interface ActivityDay {
  date: string;
  hasActivity: boolean;
  points: number;
  achievements: number;
  goals: number;
  lessonsCompleted: number;
  studyTimeMinutes: number;
}

interface ActivityStats {
  totalActiveDays: number;
  currentStreak: number;
  longestStreak: number;
  totalPoints: number;
  averageDaily: number;
  totalLessons: number;
  totalStudyTime: number;
}

const ActivityCalendar: React.FC = () => {
  const [activityData, setActivityData] = useState<ActivityDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewType, setViewType] = useState<'3months' | '6months' | '1year'>('3months');
  const [stats, setStats] = useState<ActivityStats>({
    totalActiveDays: 0,
    currentStreak: 0,
    longestStreak: 0,
    totalPoints: 0,
    averageDaily: 0,
    totalLessons: 0,
    totalStudyTime: 0,
  });

  useEffect(() => {
    fetchActivityData();
  }, [viewType]);

  const fetchActivityData = async () => {
    try {
      setLoading(true);
      const data = generateMockActivityData();
      setActivityData(data);
      calculateStats(data);
    } catch (error) {
      console.error('Failed to fetch activity data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (data: ActivityDay[]) => {
    const activeDays = data.filter(d => d.hasActivity);
    const totalPoints = data.reduce((sum, d) => sum + d.points, 0);
    const totalLessons = data.reduce((sum, d) => sum + d.lessonsCompleted, 0);
    const totalStudyTime = data.reduce((sum, d) => sum + d.studyTimeMinutes, 0);
    
    setStats({
      totalActiveDays: activeDays.length,
      currentStreak: getCurrentStreak(data),
      longestStreak: getLongestStreak(data),
      totalPoints,
      averageDaily: activeDays.length > 0 ? Math.round(totalPoints / activeDays.length) : 0,
      totalLessons,
      totalStudyTime,
    });
  };

  const getCurrentStreak = (data: ActivityDay[]): number => {
    let streak = 0;
    for (let i = data.length - 1; i >= 0; i--) {
      if (data[i].hasActivity) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  };

  const getLongestStreak = (data: ActivityDay[]): number => {
    let maxStreak = 0;
    let currentStreak = 0;
    
    data.forEach(day => {
      if (day.hasActivity) {
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
    });
    
    return maxStreak;
  };

  const generateMockActivityData = (): ActivityDay[] => {
    const data: ActivityDay[] = [];
    const today = new Date();
    const daysToGenerate = viewType === '3months' ? 90 : viewType === '6months' ? 180 : 365;
    
    for (let i = daysToGenerate - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      
      const hasActivity = Math.random() > 0.3;
      const points = hasActivity ? Math.floor(Math.random() * 100) + 10 : 0;
      const achievements = hasActivity ? Math.floor(Math.random() * 3) : 0;
      const goals = hasActivity ? Math.floor(Math.random() * 2) + 1 : 0;
      const lessonsCompleted = hasActivity ? Math.floor(Math.random() * 5) + 1 : 0;
      const studyTimeMinutes = hasActivity ? Math.floor(Math.random() * 180) + 30 : 0;
      
      data.push({
        date: date.toISOString().split('T')[0],
        hasActivity,
        points,
        achievements,
        goals,
        lessonsCompleted,
        studyTimeMinutes,
      });
    }
    
    return data;
  };

  const getCalendarWeeks = () => {
    const weeks: ActivityDay[][] = [];
    let currentWeek: ActivityDay[] = [];
    
    activityData.forEach((day, index) => {
      currentWeek.push(day);
      
      if (currentWeek.length === 7 || index === activityData.length - 1) {
        weeks.push([...currentWeek]);
        currentWeek = [];
      }
    });
    
    return weeks;
  };

  const getActivityLevel = (day: ActivityDay) => {
    if (!day.hasActivity) return 0;
    if (day.points < 20) return 1;
    if (day.points < 50) return 2;
    if (day.points < 80) return 3;
    return 4;
  };

  const getActivityColor = (level: number) => {
    const colors = [
      'rgba(235, 237, 240, 1)',
      'rgba(155, 233, 168, 0.4)',
      'rgba(64, 196, 99, 0.6)',
      'rgba(48, 161, 78, 0.8)',
      'rgba(33, 110, 57, 1)',
    ];
    return colors[level];
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const getDateRange = () => {
    if (activityData.length === 0) return '';
    const start = new Date(activityData[0].date);
    const end = new Date(activityData[activityData.length - 1].date);
    return `${start.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })} - ${end.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}`;
  };

  const weeks = getCalendarWeeks();

  return (
    <Fade in={true} timeout={1000}>
      <Card 
        sx={{ 
          mb: 3,
          background: 'linear-gradient(135deg, #f8fafc 0%, #ffffff 100%)',
          border: '1px solid #e2e8f0',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          borderRadius: 3,
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={4}>
            <Box>
              <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                <CalendarToday sx={{ color: 'primary.main' }} />
                Календарь активности
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Отслеживайте свой прогресс и поддерживайте мотивацию
              </Typography>
            </Box>
            <FormControl size="small" sx={{ minWidth: 150 }}>
              <InputLabel>Период</InputLabel>
              <Select
                value={viewType}
                onChange={(e) => setViewType(e.target.value as any)}
                label="Период"
              >
                <MenuItem value="3months">3 месяца</MenuItem>
                <MenuItem value="6months">6 месяцев</MenuItem>
                <MenuItem value="1year">1 год</MenuItem>
              </Select>
            </FormControl>
          </Box>

          <Grid container spacing={2} mb={4}>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ p: 2, textAlign: 'center', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', borderRadius: 2 }}>
                <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 0.5 }}>{stats.totalActiveDays}</Typography>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>Активных дней</Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ p: 2, textAlign: 'center', background: 'linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%)', color: 'white', borderRadius: 2 }}>
                <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 0.5 }}>{stats.currentStreak}</Typography>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>Текущий стрик</Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ p: 2, textAlign: 'center', background: 'linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%)', color: 'white', borderRadius: 2 }}>
                <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 0.5 }}>{Math.round(stats.totalStudyTime / 60)}ч</Typography>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>Время изучения</Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={0} sx={{ p: 2, textAlign: 'center', background: 'linear-gradient(135deg, #a8e6cf 0%, #7fcdcd 100%)', color: 'white', borderRadius: 2 }}>
                <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 0.5 }}>{stats.totalPoints}</Typography>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>Общие очки</Typography>
              </Paper>
            </Grid>
          </Grid>

          <Box sx={{ overflowX: 'auto', pb: 2 }}>
            <Box sx={{ minWidth: 700 }}>
              <Box mb={2}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  {getDateRange()}
                </Typography>
              </Box>

              <Grid container spacing={0.5} sx={{ mb: 1 }}>
                {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((day) => (
                  <Grid item key={day} sx={{ width: 'calc(100% / 7)' }}>
                    <Typography variant="caption" align="center" display="block" color="text.secondary" sx={{ fontWeight: 'bold' }}>
                      {day}
                    </Typography>
                  </Grid>
                ))}
              </Grid>

              {weeks.map((week, weekIndex) => (
                <Zoom in={true} timeout={500 + weekIndex * 50} key={weekIndex}>
                  <Grid container spacing={0.5} sx={{ mb: 0.5 }}>
                    {week.map((day) => {
                      const level = getActivityLevel(day);
                      return (
                        <Grid item key={day.date} sx={{ width: 'calc(100% / 7)' }}>
                          <Tooltip
                            title={
                              <Box sx={{ p: 1 }}>
                                <Typography variant="subtitle2" sx={{ fontWeight: 'bold', mb: 1 }}>
                                  {formatDate(day.date)}
                                </Typography>
                                {day.hasActivity ? (
                                  <>
                                    <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                                      <TrendingUp sx={{ fontSize: 16 }} />
                                      <Typography variant="body2">{day.points} очков</Typography>
                                    </Box>
                                    <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                                      <EmojiEvents sx={{ fontSize: 16 }} />
                                      <Typography variant="body2">{day.achievements} достижений</Typography>
                                    </Box>
                                    <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                                      <CheckCircle sx={{ fontSize: 16 }} />
                                      <Typography variant="body2">{day.lessonsCompleted} уроков</Typography>
                                    </Box>
                                    <Box display="flex" alignItems="center" gap={1}>
                                      <Insights sx={{ fontSize: 16 }} />
                                      <Typography variant="body2">
                                        {Math.round(day.studyTimeMinutes / 60)}ч {day.studyTimeMinutes % 60}мин
                                      </Typography>
                                    </Box>
                                  </>
                                ) : (
                                  <Typography variant="body2" color="text.secondary">Нет активности</Typography>
                                )}
                              </Box>
                            }
                            arrow
                            placement="top"
                          >
                            <Box
                              sx={{
                                width: 18,
                                height: 18,
                                backgroundColor: getActivityColor(level),
                                borderRadius: 1,
                                border: level > 0 ? '1px solid rgba(27, 31, 35, 0.06)' : '1px solid rgba(27, 31, 35, 0.15)',
                                cursor: 'pointer',
                                transition: 'all 0.3s ease',
                                '&:hover': {
                                  transform: 'scale(1.3)',
                                  borderRadius: 2,
                                  boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
                                  zIndex: 10,
                                },
                              }}
                            />
                          </Tooltip>
                        </Grid>
                      );
                    })}
                  </Grid>
                </Zoom>
              ))}
            </Box>
          </Box>

          <Box display="flex" alignItems="center" justifyContent="center" mt={4} mb={2}>
            <Box display="flex" alignItems="center" gap={3}>
              <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 'bold' }}>
                Меньше
              </Typography>
              <Box display="flex" gap={1}>
                {[0, 1, 2, 3, 4].map((level) => (
                  <Box
                    key={level}
                    sx={{
                      width: 14,
                      height: 14,
                      backgroundColor: getActivityColor(level),
                      borderRadius: 1,
                      border: '1px solid rgba(27, 31, 35, 0.06)',
                      transition: 'transform 0.2s ease',
                      '&:hover': { transform: 'scale(1.2)' },
                    }}
                  />
                ))}
              </Box>
              <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 'bold' }}>
                Больше
              </Typography>
            </Box>
          </Box>

          <Box mt={3} p={3} sx={{ background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)', borderRadius: 2, border: '1px solid #bae6fd' }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 'bold', mb: 1 }}>
                  📊 Статистика
                </Typography>
                <Typography variant="body2">• Самый длинный стрик: {stats.longestStreak} дней</Typography>
                <Typography variant="body2">• Среднее очков в день: {stats.averageDaily}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 'bold', mb: 1 }}>
                  🎯 Прогресс
                </Typography>
                <Typography variant="body2">• Завершено уроков: {stats.totalLessons}</Typography>
                <Typography variant="body2">• Активность: {Math.round((stats.totalActiveDays / activityData.length) * 100)}%</Typography>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>
    </Fade>
  );
};

export default ActivityCalendar;