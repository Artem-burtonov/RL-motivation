import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  Avatar,
  Chip,
  Divider,
  Grid,
  Paper,
} from '@mui/material';
import {
  TrendingUp,
  Star,
  EmojiEvents,
  KeyboardArrowUp,
  KeyboardArrowDown,
} from '@mui/icons-material';
import { userAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

interface RankingData {
  current_rank: number;
  total_users: number;
  percentile: number;
  points_to_next_level: number;
  next_level: number;
  user_above?: {
    username: string;
    full_name: string;
    total_points: number;
    points_difference: number;
  };
  user_below?: {
    username: string;
    full_name: string;
    total_points: number;
    points_difference: number;
  };
}

const RankingWidget: React.FC = () => {
  const { user } = useAuth();
  const [rankingData, setRankingData] = useState<RankingData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRankingData();
  }, []);

  const fetchRankingData = async () => {
    try {
      const data = await userAPI.getUserRanking();
      setRankingData(data);
    } catch (error) {
      console.error('Failed to fetch ranking data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return '#FFD700'; // Gold
    if (rank === 2) return '#C0C0C0'; // Silver
    if (rank === 3) return '#CD7F32'; // Bronze
    if (rank <= 10) return '#6366f1'; // Top 10
    if (rank <= 50) return '#10b981'; // Top 50
    return '#6b7280'; // Others
  };

  const getRankIcon = (rank: number) => {
    if (rank <= 3) return <EmojiEvents sx={{ color: getRankColor(rank) }} />;
    return <TrendingUp sx={{ color: getRankColor(rank) }} />;
  };

  if (loading) {
    return (
      <Card>
        <CardContent>
          <Typography>Загрузка рейтинга...</Typography>
        </CardContent>
      </Card>
    );
  }

  if (!rankingData) {
    return (
      <Card>
        <CardContent>
          <Typography color="text.secondary">
            Данные рейтинга недоступны
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const levelProgress = user?.total_points 
    ? Math.max(0, 100 - (rankingData.points_to_next_level / 1000) * 100)
    : 0;

  return (
    <Card sx={{ 
      borderRadius: 3,
      background: 'linear-gradient(135deg, #f8fafc 0%, #ffffff 100%)',
      border: '1px solid #e2e8f0',
    }}>
      <CardContent sx={{ p: 3 }}>
        <Box display="flex" alignItems="center" mb={3}>
          <Avatar sx={{ 
            bgcolor: getRankColor(rankingData.current_rank), 
            mr: 2,
            width: 48,
            height: 48,
          }}>
            {getRankIcon(rankingData.current_rank)}
          </Avatar>
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Ваш рейтинг
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Топ {rankingData.percentile}% пользователей
            </Typography>
          </Box>
        </Box>

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={6}>
            <Paper 
              sx={{ 
                p: 2, 
                textAlign: 'center',
                background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                color: 'white',
                borderRadius: 2
              }}
            >
              <Typography variant="h4" sx={{ fontWeight: 700 }}>
                #{rankingData.current_rank}
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.9 }}>
                место
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6}>
            <Paper 
              sx={{ 
                p: 2, 
                textAlign: 'center',
                background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                color: 'white',
                borderRadius: 2
              }}
            >
              <Typography variant="h4" sx={{ fontWeight: 700 }}>
                {user?.total_points || 0}
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.9 }}>
                очков
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        {rankingData.points_to_next_level > 0 && (
          <Box sx={{ mb: 3 }}>
            <Box display="flex" justifyContent="space-between" mb={1}>
              <Typography variant="body2" color="text.secondary">
                До {rankingData.next_level} уровня
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main' }}>
                {rankingData.points_to_next_level} очков
              </Typography>
            </Box>
            <LinearProgress 
              variant="determinate" 
              value={levelProgress}
              sx={{ 
                height: 8, 
                borderRadius: 4,
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                '& .MuiLinearProgress-bar': {
                  background: 'linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%)',
                  borderRadius: 4,
                }
              }}
            />
          </Box>
        )}

        <Divider sx={{ my: 2 }} />

        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
          Ближайшие соперники
        </Typography>

        {rankingData.user_above && (
          <Box display="flex" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
            <Box display="flex" alignItems="center">
              <KeyboardArrowUp color="error" sx={{ mr: 1 }} />
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {rankingData.user_above.full_name}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  #{rankingData.current_rank - 1}
                </Typography>
              </Box>
            </Box>
            <Chip 
              label={`+${rankingData.user_above.points_difference}`}
              size="small"
              color="error"
              variant="outlined"
            />
          </Box>
        )}

        {rankingData.user_below && (
          <Box display="flex" alignItems="center" justifyContent="space-between">
            <Box display="flex" alignItems="center">
              <KeyboardArrowDown color="success" sx={{ mr: 1 }} />
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {rankingData.user_below.full_name}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  #{rankingData.current_rank + 1}
                </Typography>
              </Box>
            </Box>
            <Chip 
              label={`-${rankingData.user_below.points_difference}`}
              size="small"
              color="success"
              variant="outlined"
            />
          </Box>
        )}

        {rankingData.current_rank === 1 && (
          <Box textAlign="center" sx={{ mt: 2 }}>
            <Typography variant="body2" color="primary" sx={{ fontWeight: 600 }}>
              🏆 Вы лидер! Поздравляем! 🏆
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default RankingWidget;