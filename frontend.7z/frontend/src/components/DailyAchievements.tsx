import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  LinearProgress,
  Chip,
  Avatar,
  Button,
  Paper,
  Fade,
  Zoom,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  LocalFireDepartment,
  Star,
  EmojiEvents,
  CheckCircle,
  Schedule,
  TrendingUp,
} from '@mui/icons-material';
import { achievementAPI } from '../services/api';

interface DailyAchievement {
  id: number;
  name: string;
  description: string;
  points_reward: number;
  type: string;
  is_earned_today: boolean;
  is_unlocked: boolean;
  progress: number;
  required: number;
}

interface DailyStats {
  streak_days: number;
  daily_achievements: any[];
  total_points_today: number;
}

const DailyAchievements: React.FC = () => {
  const [dailyAchievements, setDailyAchievements] = useState<DailyAchievement[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [claimDialog, setClaimDialog] = useState<DailyAchievement | null>(null);

  useEffect(() => {
    fetchDailyData();
  }, []);

  const fetchDailyData = async () => {
    try {
      setLoading(true);
      
      // Fetch daily achievements and check for new ones
      const [achievements, stats] = await Promise.all([
        achievementAPI.getDailyAchievements(),
        achievementAPI.checkDailyAchievements()
      ]);
      
      setDailyAchievements(achievements);
      setDailyStats(stats);
    } catch (error) {
      console.error('Failed to fetch daily achievements:', error);
    } finally {
      setLoading(false);
    }
  };

  const getAchievementIcon = (type: string) => {
    switch (type) {
      case 'daily_visit':
        return <Star color="warning" />;
      case 'streak_3':
      case 'streak_7':
      case 'streak_30':
        return <LocalFireDepartment color="error" />;
      default:
        return <EmojiEvents color="primary" />;
    }
  };

  const getAchievementColor = (achievement: DailyAchievement) => {
    if (achievement.is_earned_today) return 'success';
    if (achievement.is_unlocked) return 'primary';
    return 'default';
  };

  const getProgressPercentage = (achievement: DailyAchievement) => {
    return Math.min((achievement.progress / achievement.required) * 100, 100);
  };

  const handleClaimClose = () => {
    setClaimDialog(null);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <Typography>Загрузка ежедневных достижений...</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Fade in={true} timeout={1000}>
        <Paper 
          elevation={3} 
          sx={{ 
            p: 3, 
            mb: 4, 
            background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)',
            color: 'white',
            borderRadius: 3
          }}
        >
          <Box display="flex" alignItems="center" justifyContent="space-between">
            <Box>
              <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
                🌅 Ежедневные Достижения
              </Typography>
              <Typography variant="h6" sx={{ opacity: 0.9 }}>
                Выполняйте ежедневные задачи и получайте бонусы!
              </Typography>
            </Box>
            
            {dailyStats && (
              <Box textAlign="center">
                <Typography variant="h3" sx={{ fontWeight: 'bold', mb: 1 }}>
                  🔥 {dailyStats.streak_days}
                </Typography>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>
                  дней подряд
                </Typography>
              </Box>
            )}
          </Box>
        </Paper>
      </Fade>

      {dailyStats && dailyStats.total_points_today > 0 && (
        <Fade in={true} timeout={1200}>
          <Paper
            elevation={2}
            sx={{
              p: 2,
              mb: 3,
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              color: 'white',
              borderRadius: 2,
              textAlign: 'center'
            }}
          >
            <Typography variant="h6" gutterBottom>
              🎉 Заработано сегодня: +{dailyStats.total_points_today} очков!
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.9 }}>
              {dailyStats.daily_achievements.length} достижений разблокировано
            </Typography>
          </Paper>
        </Fade>
      )}

      <Grid container spacing={3}>
        {dailyAchievements.map((achievement, index) => (
          <Grid item xs={12} sm={6} md={3} key={achievement.id}>
            <Fade in={true} timeout={1000 + index * 200}>
              <Card 
                sx={{ 
                  height: '100%',
                  position: 'relative',
                  background: achievement.is_earned_today 
                    ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
                    : achievement.is_unlocked 
                      ? 'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)'
                      : 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
                  color: achievement.is_earned_today || achievement.is_unlocked ? 'white' : 'text.primary',
                  transform: achievement.is_earned_today ? 'scale(1.02)' : 'scale(1)',
                  transition: 'all 0.3s ease-in-out',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: 4,
                  }
                }}
              >
                {achievement.is_earned_today && (
                  <Chip
                    label="Сегодня!"
                    size="small"
                    sx={{
                      position: 'absolute',
                      top: -10,
                      right: 10,
                      bgcolor: 'warning.main',
                      color: 'white',
                      fontWeight: 'bold',
                      zIndex: 1
                    }}
                  />
                )}
                
                <CardContent sx={{ textAlign: 'center', pb: 2 }}>
                  <Zoom in={true} timeout={1500 + index * 100}>
                    <Avatar
                      sx={{
                        width: 60,
                        height: 60,
                        mx: 'auto',
                        mb: 2,
                        bgcolor: achievement.is_earned_today 
                          ? 'rgba(255,255,255,0.2)' 
                          : achievement.is_unlocked 
                            ? 'rgba(255,255,255,0.2)'
                            : 'primary.main'
                      }}
                    >
                      {achievement.is_earned_today ? 
                        <CheckCircle sx={{ fontSize: 32 }} /> :
                        getAchievementIcon(achievement.type)
                      }
                    </Avatar>
                  </Zoom>
                  
                  <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
                    {achievement.name}
                  </Typography>
                  
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      mb: 2, 
                      opacity: achievement.is_earned_today || achievement.is_unlocked ? 0.9 : 0.7,
                      minHeight: '40px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {achievement.description}
                  </Typography>
                  
                  {!achievement.is_earned_today && !achievement.is_unlocked && (
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="caption" sx={{ mb: 1, display: 'block' }}>
                        Прогресс: {achievement.progress}/{achievement.required}
                      </Typography>
                      <LinearProgress 
                        variant="determinate" 
                        value={getProgressPercentage(achievement)}
                        sx={{
                          height: 6,
                          borderRadius: 3,
                          bgcolor: 'rgba(0,0,0,0.1)',
                          '& .MuiLinearProgress-bar': {
                            borderRadius: 3,
                            bgcolor: 'primary.main'
                          }
                        }}
                      />
                    </Box>
                  )}
                  
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                      +{achievement.points_reward} очков
                    </Typography>
                    
                    {achievement.is_earned_today && (
                      <CheckCircle color="inherit" sx={{ fontSize: 20 }} />
                    )}
                    
                    {achievement.is_unlocked && !achievement.is_earned_today && (
                      <Chip 
                        label="Получено" 
                        size="small" 
                        sx={{ 
                          bgcolor: 'rgba(255,255,255,0.2)',
                          color: 'inherit'
                        }} 
                      />
                    )}
                  </Box>
                </CardContent>
              </Card>
            </Fade>
          </Grid>
        ))}
      </Grid>

      <Dialog open={!!claimDialog} onClose={handleClaimClose}>
        <DialogTitle sx={{ textAlign: 'center' }}>
          🎉 Достижение разблокировано!
        </DialogTitle>
        <DialogContent sx={{ textAlign: 'center', pb: 2 }}>
          {claimDialog && (
            <>
              <Avatar
                sx={{
                  width: 80,
                  height: 80,
                  mx: 'auto',
                  mb: 2,
                  bgcolor: 'primary.main'
                }}
              >
                {getAchievementIcon(claimDialog.type)}
              </Avatar>
              <Typography variant="h6" gutterBottom>
                {claimDialog.name}
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                {claimDialog.description}
              </Typography>
              <Typography variant="h5" color="primary" sx={{ fontWeight: 'bold' }}>
                +{claimDialog.points_reward} очков!
              </Typography>
            </>
          )}
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 3 }}>
          <Button 
            onClick={handleClaimClose} 
            variant="contained" 
            size="large"
            sx={{ minWidth: 120 }}
          >
            Отлично!
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DailyAchievements;