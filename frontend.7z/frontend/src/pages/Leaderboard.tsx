import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Avatar,
  Chip,
  Tabs,
  Tab,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
} from '@mui/material';
import {
  EmojiEvents,
  Star,
  LocalFireDepartment,
  School,
} from '@mui/icons-material';
import { leaderboardAPI, courseAPI } from '../services/api';
import { LeaderboardEntry, Course } from '../types';
import { useAuth } from '../contexts/AuthContext';

const Leaderboard: React.FC = () => {
  const { user } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<number | undefined>(undefined);
  const [tabValue, setTabValue] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCourses();
    fetchLeaderboard();
  }, []);

  const fetchCourses = async () => {
    try {
      const data = await courseAPI.getCourses();
      setCourses(data);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    }
  };

  const fetchLeaderboard = async (courseId?: number) => {
    try {
      setLoading(true);
      const data = await leaderboardAPI.getLeaderboard(courseId, 50);
      setLeaderboard(data);
    } catch (error) {
      console.error('Failed to fetch leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCourseChange = (courseId: number | undefined) => {
    setSelectedCourse(courseId);
    fetchLeaderboard(courseId);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
    // Here you would implement different leaderboard types
    // For now, we'll just use the general leaderboard
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <EmojiEvents sx={{ color: '#FFD700' }} />;
    if (rank === 2) return <EmojiEvents sx={{ color: '#C0C0C0' }} />;
    if (rank === 3) return <EmojiEvents sx={{ color: '#CD7F32' }} />;
    return rank;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'warning';
    if (rank === 2) return 'default';
    if (rank === 3) return 'secondary';
    return 'default';
  };

  if (loading) {
    return <Box>Загрузка...</Box>;
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Рейтинг
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Общий рейтинг" />
          <Tab label="По курсам" />
          <Tab label="По сериям" />
        </Tabs>
      </Box>

      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth>
            <InputLabel>Курс</InputLabel>
            <Select
              value={selectedCourse || ''}
              onChange={(e) => handleCourseChange(e.target.value as number || undefined)}
            >
              <MenuItem value="">
                <em>Все курсы</em>
              </MenuItem>
              {courses.map((course) => (
                <MenuItem key={course.id} value={course.id}>
                  {course.title}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Card>
        <CardContent>
          <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Место</TableCell>
                  <TableCell>Пользователь</TableCell>
                  <TableCell align="right">Очки</TableCell>
                  <TableCell align="right">Уровень</TableCell>
                  <TableCell align="right">Серия</TableCell>
                  <TableCell align="right">Завершение</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {leaderboard.map((entry, index) => (
                  <TableRow
                    key={entry.user_id}
                    sx={{
                      backgroundColor: entry.user_id === user?.id ? 'action.hover' : 'inherit',
                      '&:hover': {
                        backgroundColor: 'action.selected',
                      },
                    }}
                  >
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        {getRankIcon(entry.rank)}
                        <Typography variant="body2" sx={{ ml: 1 }}>
                          #{entry.rank}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <Avatar
                          src={entry.avatar_url}
                          sx={{ width: 32, height: 32, mr: 2 }}
                        >
                          {entry.full_name.charAt(0)}
                        </Avatar>
                        <Box>
                          <Typography variant="body2" fontWeight="medium">
                            {entry.full_name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            @{entry.username}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Box display="flex" alignItems="center" justifyContent="flex-end">
                        <Star sx={{ mr: 0.5, fontSize: 16 }} />
                        <Typography variant="body2" fontWeight="medium">
                          {entry.total_points.toLocaleString()}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Chip
                        label={`Уровень ${entry.level}`}
                        color="primary"
                        size="small"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Box display="flex" alignItems="center" justifyContent="flex-end">
                        <LocalFireDepartment sx={{ mr: 0.5, fontSize: 16, color: 'error.main' }} />
                        <Typography variant="body2">
                          {entry.streak_days} дней
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Box display="flex" alignItems="center" justifyContent="flex-end">
                        <School sx={{ mr: 0.5, fontSize: 16, color: 'success.main' }} />
                        <Typography variant="body2">
                          {Math.round(entry.completion_rate)}%
                        </Typography>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {leaderboard.length === 0 && (
        <Box textAlign="center" py={4}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            Рейтинг пуст
          </Typography>
          <Typography color="text.secondary">
            Начните обучение, чтобы попасть в рейтинг!
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default Leaderboard;

