import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  Button,
  CardMedia,
  CardActions,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tabs,
  Tab,
  Fade,
  Zoom,
  Paper,
} from '@mui/material';
import {
  PlayArrow,
  School,
  Schedule,
  TrendingUp,
  Add,
  Edit,
  AutoAwesome,
  PsychologyAlt,
  Rocket,
} from '@mui/icons-material';
import { courseAPI, progressAPI } from '../services/api';
import { Course, Progress } from '../types';

const Courses: React.FC = () => {
  const navigate = useNavigate();
  const [courses, setCourses] = useState<Course[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  const [open, setOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    duration_hours: 0,
    difficulty_level: 'beginner',
    category: '',
    thumbnail_url: '',
    max_points: 1000,
    completion_bonus: 100,
  });

  useEffect(() => {
    fetchCourses();
    fetchProgress();
  }, []);

  const fetchCourses = async () => {
    try {
      const data = await courseAPI.getCourses();
      setCourses(data);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProgress = async () => {
    try {
      const data = await progressAPI.getUserProgress();
      setProgress(data);
    } catch (error) {
      console.error('Failed to fetch progress:', error);
    }
  };

  const getCourseProgress = (courseId: number) => {
    const courseProgress = progress.find(p => p.course_id === courseId);
    return courseProgress || null;
  };

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'beginner':
        return 'success';
      case 'intermediate':
        return 'warning';
      case 'advanced':
        return 'error';
      default:
        return 'default';
    }
  };

  const getDifficultyText = (level: string) => {
    switch (level) {
      case 'beginner':
        return 'Начинающий';
      case 'intermediate':
        return 'Средний';
      case 'advanced':
        return 'Продвинутый';
      default:
        return level;
    }
  };

  const handleOpen = (course?: Course) => {
    if (course) {
      setEditingCourse(course);
      setFormData({
        title: course.title,
        description: course.description || '',
        duration_hours: course.duration_hours,
        difficulty_level: course.difficulty_level,
        category: course.category || '',
        thumbnail_url: course.thumbnail_url || '',
        max_points: course.max_points,
        completion_bonus: course.completion_bonus,
      });
    } else {
      setEditingCourse(null);
      setFormData({
        title: '',
        description: '',
        duration_hours: 0,
        difficulty_level: 'beginner',
        category: '',
        thumbnail_url: '',
        max_points: 1000,
        completion_bonus: 100,
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingCourse(null);
  };

  const handleSubmit = async () => {
    // Validate form data
    if (!formData.title.trim()) {
      alert('Пожалуйста, введите название курса');
      return;
    }
    
    if (!formData.description.trim()) {
      alert('Пожалуйста, введите описание курса');
      return;
    }
    
    if (formData.duration_hours <= 0) {
      alert('Продолжительность курса должна быть больше нуля');
      return;
    }
    
    if (formData.max_points <= 0) {
      alert('Максимальное количество очков должно быть больше нуля');
      return;
    }
    
    try {
      console.log('Submitting course data:', formData);
      
      if (editingCourse) {
        const result = await courseAPI.updateCourse(editingCourse.id, formData);
        console.log('Course updated:', result);
      } else {
        const result = await courseAPI.createCourse(formData);
        console.log('Course created:', result);
      }
      
      await fetchCourses();
      handleClose();
      
      // Show success message
      alert(editingCourse ? 'Курс успешно обновлён!' : 'Курс успешно создан!');
      
    } catch (error: any) {
      console.error('Failed to save course:', error);
      
      // Show detailed error message
      const errorMessage = error.response?.data?.detail || error.message || 'Неизвестная ошибка';
      alert(`Ошибка при сохранении курса: ${errorMessage}`);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSelectChange = (e: any) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleEnroll = async (courseId: number) => {
    try {
      await courseAPI.enrollInCourse(courseId);
      fetchCourses();
      fetchProgress();
    } catch (error: any) {
      console.error('Failed to enroll in course:', error);
    }
  };

  const enrolledCourses = courses.filter(course => 
    progress.some(p => p.course_id === course.id)
  );

  const availableCourses = courses.filter(course => 
    !progress.some(p => p.course_id === course.id)
  );

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  if (loading) {
    return <Box>Загрузка...</Box>;
  }

  const displayCourses = tabValue === 0 ? courses : tabValue === 1 ? enrolledCourses : availableCourses;

  return (
    <Box>
      <Fade in={true} timeout={1000}>
        <Paper 
          elevation={3} 
          sx={{ 
            p: 3, 
            mb: 4, 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            borderRadius: 3
          }}
        >
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Box>
              <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
                Курсы 📚
              </Typography>
              <Typography variant="h6" sx={{ opacity: 0.9 }}>
                Изучайте новые темы и развивайтесь!
              </Typography>
            </Box>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => handleOpen()}
              sx={{
                bgcolor: 'rgba(255,255,255,0.2)',
                color: 'white',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.3)',
                }
              }}
            >
              Создать курс
            </Button>
          </Box>
        </Paper>
      </Fade>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label={`Все (${courses.length})`} />
          <Tab label={`Записанные (${enrolledCourses.length})`} />
          <Tab label={`Доступные (${availableCourses.length})`} />
        </Tabs>
      </Box>

      <Grid container spacing={3}>
        {displayCourses.map((course, index) => {
          const courseProgress = getCourseProgress(course.id);
          const isEnrolled = !!courseProgress;
          const isCompleted = courseProgress?.is_completed || false;

          return (
            <Grid item xs={12} sm={6} md={4} key={course.id}>
              <Fade in={true} timeout={1200 + index * 200}>
                <Card 
                  sx={{ 
                    height: '100%', 
                    display: 'flex', 
                    flexDirection: 'column',
                    transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: 4,
                    }
                  }}
                >
                {course.thumbnail_url && (
                  <CardMedia
                    component="img"
                    height="140"
                    image={course.thumbnail_url}
                    alt={course.title}
                  />
                )}
                
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant="h6" component="div" gutterBottom>
                    {course.title}
                  </Typography>
                  
                  {course.description && (
                    <Typography color="text.secondary" paragraph>
                      {course.description.length > 100 
                        ? `${course.description.substring(0, 100)}...` 
                        : course.description
                      }
                    </Typography>
                  )}

                  <Box display="flex" gap={1} mb={2}>
                    <Chip
                      label={getDifficultyText(course.difficulty_level)}
                      color={getDifficultyColor(course.difficulty_level) as any}
                      size="small"
                    />
                    {course.category && (
                      <Chip
                        label={course.category}
                        size="small"
                        variant="outlined"
                      />
                    )}
                  </Box>

                  <Box display="flex" alignItems="center" gap={2} mb={2}>
                    <Box display="flex" alignItems="center">
                      <Schedule sx={{ mr: 0.5, fontSize: 16 }} />
                      <Typography variant="body2" color="text.secondary">
                        {course.duration_hours}ч
                      </Typography>
                    </Box>
                    <Box display="flex" alignItems="center">
                      <TrendingUp sx={{ mr: 0.5, fontSize: 16 }} />
                      <Typography variant="body2" color="text.secondary">
                        {course.max_points} очков
                      </Typography>
                    </Box>
                  </Box>

                  {isEnrolled && courseProgress && (
                    <Box mb={2}>
                      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                        <Typography variant="body2" color="text.secondary">
                          Прогресс
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {Math.round(Math.min(courseProgress.completion_percentage || 0, 100))}%
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={Math.min(courseProgress.completion_percentage || 0, 100)}
                        sx={{ 
                          mb: 1,
                          height: 8,
                          borderRadius: 4,
                          bgcolor: 'rgba(0,0,0,0.1)',
                          '& .MuiLinearProgress-bar': {
                            borderRadius: 4,
                          }
                        }}
                      />
                      <Typography variant="caption" color="text.secondary">
                        {courseProgress.lessons_completed} из {courseProgress.total_lessons} уроков
                      </Typography>
                    </Box>
                  )}

                  {isCompleted && (
                    <Chip
                      label="Завершено"
                      color="success"
                      size="small"
                      sx={{ mb: 2 }}
                    />
                  )}
                </CardContent>

                <CardActions>
                  <Button
                    size="small"
                    startIcon={<PlayArrow />}
                    variant={isEnrolled ? "contained" : "outlined"}
                    fullWidth
                    onClick={() => isEnrolled ? navigate(`/courses/${course.id}`) : handleEnroll(course.id)}
                    disabled={isCompleted}
                  >
                    {isCompleted ? 'Завершено' : isEnrolled ? 'Продолжить' : 'Начать курс'}
                  </Button>
                  <Button
                    size="small"
                    startIcon={<Edit />}
                    onClick={() => handleOpen(course)}
                  >
                    Редактировать
                  </Button>
                </CardActions>
              </Card>
              </Fade>
            </Grid>
          );
        })}
      </Grid>

      {displayCourses.length === 0 && (
        <Fade in={true} timeout={1500}>
          <Box textAlign="center" py={6}>
            <Zoom in={true} timeout={2000}>
              <Box mb={3}>
                <School sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
              </Box>
            </Zoom>
            <Typography variant="h5" color="text.secondary" gutterBottom sx={{ fontWeight: 'bold' }}>
              Курсы не найдены
            </Typography>
            <Typography color="text.secondary" paragraph>
              {tabValue === 0 && "Создайте первый курс для начала обучения"}
              {tabValue === 1 && "Вы пока не записаны ни на один курс"}
              {tabValue === 2 && "Все доступные курсы уже записаны"}
            </Typography>
          </Box>
        </Fade>
      )}

      {/* Диалог создания/редактирования курса */}
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingCourse ? 'Редактировать курс' : 'Создать новый курс'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Название курса"
                name="title"
                value={formData.title}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Описание"
                name="description"
                multiline
                rows={3}
                value={formData.description}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Длительность (часы)"
                name="duration_hours"
                type="number"
                value={formData.duration_hours}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Уровень сложности</InputLabel>
                <Select
                  name="difficulty_level"
                  value={formData.difficulty_level}
                  onChange={handleSelectChange}
                >
                  <MenuItem value="beginner">Начинающий</MenuItem>
                  <MenuItem value="intermediate">Средний</MenuItem>
                  <MenuItem value="advanced">Продвинутый</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Категория"
                name="category"
                value={formData.category}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="URL изображения"
                name="thumbnail_url"
                value={formData.thumbnail_url}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Максимум очков"
                name="max_points"
                type="number"
                value={formData.max_points}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Бонус за завершение"
                name="completion_bonus"
                type="number"
                value={formData.completion_bonus}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Отмена</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editingCourse ? 'Сохранить' : 'Создать'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Courses;

