import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  Avatar,
  LinearProgress,
  Tabs,
  Tab,
  Fade,
  Zoom,
  Paper,
} from '@mui/material';
import {
  EmojiEvents,
  Star,
  LocalFireDepartment,
  School,
  Diamond,
  AutoAwesome,
  PsychologyAlt,
  Rocket,
} from '@mui/icons-material';
import { achievementAPI } from '../services/api';
import { Achievement } from '../types';

const Achievements: React.FC = () => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    fetchAchievements();
  }, []);

  const fetchAchievements = async () => {
    try {
      const data = await achievementAPI.getUserAchievements();
      setAchievements(data);
    } catch (error) {
      console.error('Failed to fetch achievements:', error);
    } finally {
      setLoading(false);
    }
  };

  const getAchievementIcon = (type?: string) => {
    switch (type) {
      case 'streak_3':
      case 'streak_7':
      case 'streak_30':
        return <LocalFireDepartment />;
      case 'registration':
      case 'first_goal':
      case 'daily_visit':
        return <Star />;
      case 'first_goal_complete':
      case 'goals_5':
        return <School />;
      case 'level_2':
      case 'level_5':
        return <EmojiEvents />;
      default:
        return <Diamond />;
    }
  };

  const getAchievementColor = (type?: string) => {
    switch (type) {
      case 'streak_3':
      case 'streak_7':
      case 'streak_30':
        return 'error';
      case 'registration':
      case 'first_goal':
      case 'daily_visit':
        return 'warning';
      case 'first_goal_complete':
      case 'goals_5':
        return 'success';
      case 'level_2':
      case 'level_5':
        return 'primary';
      default:
        return 'default';
    }
  };

  const getTypeText = (type?: string) => {
    if (!type) return 'Общее';
    if (type.includes('streak')) return 'Серия';
    if (type.includes('level')) return 'Уровень';
    if (type.includes('goal')) return 'Цели';
    if (type === 'registration') return 'Регистрация';
    if (type === 'daily_visit') return 'Ежедневно';
    return type;
  };

  const unlockedAchievements = achievements.filter(a => a.is_unlocked);
  const lockedAchievements = achievements.filter(a => !a.is_unlocked);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  if (loading) {
    return <Box>Загрузка...</Box>;
  }

  return (
    <Box>
      <Fade in={true} timeout={1000}>
        <Paper 
          elevation={3} 
          sx={{ 
            p: 3, 
            mb: 4, 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            borderRadius: 3
          }}
        >
          <Box display="flex" alignItems="center" mb={2}>
            <EmojiEvents sx={{ mr: 2, fontSize: 40 }} />
            <Box>
              <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
                Достижения 🏆
              </Typography>
              <Typography variant="h6" sx={{ opacity: 0.9 }}>
                Собирайте награды за свои успехи!
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Fade>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label={`Все (${achievements.length})`} />
          <Tab label={`Разблокированные (${unlockedAchievements.length})`} />
          <Tab label={`Заблокированные (${lockedAchievements.length})`} />
        </Tabs>
      </Box>

      <Grid container spacing={3}>
        {(tabValue === 0 ? achievements : tabValue === 1 ? unlockedAchievements : lockedAchievements).map((achievement, index) => (
          <Grid item xs={12} sm={6} md={4} key={achievement.id}>
            <Fade in={true} timeout={1200 + index * 200}>
              <Card 
                sx={{ 
                  opacity: achievement.is_unlocked ? 1 : 0.6,
                  position: 'relative',
                  overflow: 'visible',
                  height: '100%',
                  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: 4,
                  }
                }}
              >
              {achievement.is_unlocked && (
                <Chip
                  label="Разблокировано"
                  color="success"
                  size="small"
                  sx={{
                    position: 'absolute',
                    top: -10,
                    right: 10,
                    zIndex: 1
                  }}
                />
              )}
              
              <CardContent>
                <Box display="flex" alignItems="center" mb={2}>
                  <Avatar
                    sx={{
                      bgcolor: achievement.is_unlocked ? `${getAchievementColor(achievement.type)}.main` : 'grey.400',
                      mr: 2,
                      width: 56,
                      height: 56
                    }}
                  >
                    {getAchievementIcon(achievement.type)}
                  </Avatar>
                  <Box>
                    <Typography variant="h6" component="div">
                      {achievement.name}
                    </Typography>
                    <Chip
                      label={getTypeText(achievement.type)}
                      color={getAchievementColor(achievement.type) as any}
                      size="small"
                      variant="outlined"
                    />
                  </Box>
                </Box>

                <Typography color="text.secondary" paragraph>
                  {achievement.description}
                </Typography>

                <Box display="flex" justifyContent="space-between" alignItems="center">
                  <Typography variant="body2" color="primary">
                    +{achievement.points_reward} очков
                  </Typography>
                  {achievement.is_unlocked && achievement.unlocked_at && (
                    <Typography variant="caption" color="text.secondary">
                      Получено: {new Date(achievement.unlocked_at).toLocaleDateString()}
                    </Typography>
                  )}
                </Box>
              </CardContent>
            </Card>
            </Fade>
          </Grid>
        ))}
      </Grid>

      {achievements.length === 0 && (
        <Fade in={true} timeout={1500}>
          <Box textAlign="center" py={6}>
            <Zoom in={true} timeout={2000}>
              <Box mb={3}>
                <EmojiEvents sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
              </Box>
            </Zoom>
            <Typography variant="h5" color="text.secondary" gutterBottom sx={{ fontWeight: 'bold' }}>
              Достижения не найдены
            </Typography>
            <Typography color="text.secondary" paragraph>
              Начните обучение, чтобы получить свои первые достижения!
            </Typography>
          </Box>
        </Fade>
      )}
    </Box>
  );
};

export default Achievements;

