import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  LinearProgress,
  Chip,
  IconButton,
  Fab,
  Fade,
  Zoom,
  Tooltip,
  Paper,
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  CheckCircle,
  Flag,
  AutoAwesome,
  TrendingUp,
  PsychologyAlt,
} from '@mui/icons-material';
import { goalAPI, courseAPI } from '../services/api';
import { Goal, GoalCreate, Course } from '../types';

const Goals: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [open, setOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [formData, setFormData] = useState<GoalCreate>({
    course_id: 0,
    title: '',
    description: '',
    goal_type: 'daily',
    target_value: 1,
    points_reward: 10,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGoals();
    fetchCourses();
  }, []);

  const fetchGoals = async () => {
    try {
      const data = await goalAPI.getUserGoals();
      setGoals(data);
    } catch (error) {
      console.error('Failed to fetch goals:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCourses = async () => {
    try {
      const data = await courseAPI.getCourses();
      setCourses(data);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    }
  };

  const handleOpen = (goal?: Goal) => {
    if (goal) {
      setEditingGoal(goal);
      setFormData({
        course_id: goal.course_id,
        title: goal.title,
        description: goal.description || '',
        goal_type: goal.goal_type,
        target_value: goal.target_value,
        points_reward: goal.points_reward,
      });
    } else {
      setEditingGoal(null);
      setFormData({
        course_id: 0,
        title: '',
        description: '',
        goal_type: 'daily',
        target_value: 1,
        points_reward: 10,
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingGoal(null);
  };

  const handleSubmit = async () => {
    // Validate form data
    if (!formData.title.trim()) {
      alert('Пожалуйста, введите название цели');
      return;
    }
    
    if (formData.target_value <= 0) {
      alert('Целевое значение должно быть больше нуля');
      return;
    }
    
    if (formData.points_reward <= 0) {
      alert('Награда в очках должна быть больше нуля');
      return;
    }
    
    try {
      console.log('Submitting goal data:', formData);
      
      if (editingGoal) {
        const result = await goalAPI.updateGoal(editingGoal.id, formData);
        console.log('Goal updated:', result);
      } else {
        const result = await goalAPI.createGoal(formData);
        console.log('Goal created:', result);
      }
      
      await fetchGoals();
      handleClose();
      
      // Show success message
      alert(editingGoal ? 'Цель успешно обновлена!' : 'Цель успешно создана!');
      
    } catch (error: any) {
      console.error('Failed to save goal:', error);
      
      // Show detailed error message
      const errorMessage = error.response?.data?.detail || error.message || 'Неизвестная ошибка';
      alert(`Ошибка при сохранении цели: ${errorMessage}`);
    }
  };

  const handleComplete = async (goalId: number) => {
    try {
      await goalAPI.completeGoal(goalId);
      fetchGoals();
    } catch (error: any) {
      console.error('Failed to complete goal:', error);
    }
  };

  const handleDelete = async (goalId: number) => {
    if (window.confirm('Вы уверены, что хотите удалить эту цель?')) {
      try {
        await goalAPI.deleteGoal(goalId);
        fetchGoals();
      } catch (error: any) {
        console.error('Failed to delete goal:', error);
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'in_progress':
        return 'primary';
      case 'failed':
        return 'error';
      default:
        return 'default';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Завершено';
      case 'in_progress':
        return 'В процессе';
      case 'failed':
        return 'Провалено';
      case 'pending':
        return 'Ожидает';
      default:
        return status;
    }
  };

  if (loading) {
    return <Box>Загрузка...</Box>;
  }

  return (
    <Box>
      <Fade in={true} timeout={1000}>
        <Paper 
          elevation={3} 
          sx={{ 
            p: 3, 
            mb: 4, 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            borderRadius: 3
          }}
        >
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Box>
              <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
                Мои цели 🎯
              </Typography>
              <Typography variant="h6" sx={{ opacity: 0.9 }}>
                Ставьте цели и достигайте их!
              </Typography>
            </Box>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => handleOpen()}
              sx={{
                bgcolor: 'rgba(255,255,255,0.2)',
                color: 'white',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.3)',
                }
              }}
            >
              Создать цель
            </Button>
          </Box>
        </Paper>
      </Fade>

      <Grid container spacing={3}>
        {goals.map((goal, index) => (
          <Grid item xs={12} md={6} lg={4} key={goal.id}>
            <Fade in={true} timeout={1200 + index * 200}>
              <Card 
                sx={{ 
                  height: '100%',
                  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: 4,
                  }
                }}
              >
                <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                  <Typography variant="h6" component="div">
                    {goal.title}
                  </Typography>
                  <Chip
                    label={getStatusText(goal.status)}
                    color={getStatusColor(goal.status) as any}
                    size="small"
                  />
                </Box>

                {goal.description && (
                  <Typography color="text.secondary" gutterBottom>
                    {goal.description}
                  </Typography>
                )}

                <Box mb={2}>
                  <LinearProgress
                    variant="determinate"
                    value={Math.min(goal.progress_percentage || 0, 100)}
                    sx={{ 
                      mb: 1,
                      height: 8,
                      borderRadius: 4,
                      bgcolor: 'rgba(0,0,0,0.1)',
                      '& .MuiLinearProgress-bar': {
                        borderRadius: 4,
                      }
                    }}
                  />
                  <Typography variant="caption" color="text.secondary">
                    {goal.current_value} из {goal.target_value} ({Math.round(goal.progress_percentage || 0)}%)
                  </Typography>
                </Box>

                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Chip
                    icon={<Flag />}
                    label={goal.goal_type}
                    size="small"
                    variant="outlined"
                  />
                  <Typography variant="body2" color="primary">
                    +{goal.points_reward} очков
                  </Typography>
                </Box>

                <Box display="flex" justifyContent="space-between">
                  <Box>
                    <IconButton
                      size="small"
                      onClick={() => handleOpen(goal)}
                    >
                      <Edit />
                    </IconButton>
                    <IconButton
                      size="small"
                      onClick={() => handleDelete(goal.id)}
                    >
                      <Delete />
                    </IconButton>
                  </Box>
                  {goal.status !== 'completed' && (
                    <Button
                      size="small"
                      variant="contained"
                      startIcon={<CheckCircle />}
                      onClick={() => handleComplete(goal.id)}
                    >
                      Завершить
                    </Button>
                  )}
                </Box>
              </CardContent>
            </Card>
            </Fade>
          </Grid>
        ))}
      </Grid>

      {goals.length === 0 && (
        <Fade in={true} timeout={1500}>
          <Box textAlign="center" py={6}>
            <Zoom in={true} timeout={2000}>
              <Box mb={3}>
                <Flag sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
              </Box>
            </Zoom>
            <Typography variant="h5" color="text.secondary" gutterBottom sx={{ fontWeight: 'bold' }}>
              У вас пока нет целей
            </Typography>
            <Typography color="text.secondary" paragraph sx={{ mb: 4 }}>
              Создайте свою первую цель для начала обучения
            </Typography>
            <Button
              variant="contained"
              size="large"
              startIcon={<Add />}
              onClick={() => handleOpen()}
              sx={{
                background: 'linear-gradient(45deg, #667eea 0%, #764ba2 100%)',
                '&:hover': {
                  background: 'linear-gradient(45deg, #5a6fd8 0%, #6a4190 100%)',
                }
              }}
            >
              Создать цель
            </Button>
          </Box>
        </Fade>
      )}

      {/* Диалог создания/редактирования цели */}
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingGoal ? 'Редактировать цель' : 'Создать новую цель'}
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Название цели"
            fullWidth
            variant="outlined"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            sx={{ mb: 2 }}
          />
          
          <TextField
            margin="dense"
            label="Описание"
            fullWidth
            multiline
            rows={3}
            variant="outlined"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            sx={{ mb: 2 }}
          />

          <FormControl fullWidth margin="dense" sx={{ mb: 2 }}>
            <InputLabel>Курс</InputLabel>
            <Select
              value={formData.course_id}
              onChange={(e) => setFormData({ ...formData, course_id: Number(e.target.value) })}
            >
              {courses.map((course) => (
                <MenuItem key={course.id} value={course.id}>
                  {course.title}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth margin="dense" sx={{ mb: 2 }}>
            <InputLabel>Тип цели</InputLabel>
            <Select
              value={formData.goal_type}
              onChange={(e) => setFormData({ ...formData, goal_type: e.target.value as any })}
            >
              <MenuItem value="daily">Ежедневная</MenuItem>
              <MenuItem value="weekly">Еженедельная</MenuItem>
              <MenuItem value="monthly">Ежемесячная</MenuItem>
              <MenuItem value="custom">Пользовательская</MenuItem>
            </Select>
          </FormControl>

          <TextField
            margin="dense"
            label="Целевое значение"
            type="number"
            fullWidth
            variant="outlined"
            value={formData.target_value}
            onChange={(e) => setFormData({ ...formData, target_value: Number(e.target.value) })}
            sx={{ mb: 2 }}
          />

          <TextField
            margin="dense"
            label="Награда (очки)"
            type="number"
            fullWidth
            variant="outlined"
            value={formData.points_reward}
            onChange={(e) => setFormData({ ...formData, points_reward: Number(e.target.value) })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Отмена</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editingGoal ? 'Сохранить' : 'Создать'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Goals;

