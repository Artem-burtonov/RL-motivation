import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  LinearProgress,
  Button,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Chip,
  Paper,
  Divider,
  CircularProgress,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  PlayArrow,
  CheckCircle,
  Lock,
  Schedule,
  TrendingUp,
  ArrowBack,
  School,
  EmojiEvents,
} from '@mui/icons-material';
import { courseAPI } from '../services/api';

interface Lesson {
  id: number;
  course_id: number;
  title: string;
  description: string;
  order: number;
  points: number;
  duration_minutes: number;
  is_completed?: boolean;
  completed_at?: string;
}

interface CourseDetail {
  id: number;
  title: string;
  description: string;
  difficulty_level: string;
  duration_hours: number;
  category: string;
  thumbnail_url?: string;
  max_points: number;
  completion_bonus: number;
  lessons: Lesson[];
  total_lessons: number;
}

const CourseDetailPage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [progress, setProgress] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [completingLesson, setCompletingLesson] = useState<number | null>(null);
  const [lessonDialog, setLessonDialog] = useState<Lesson | null>(null);

  useEffect(() => {
    if (courseId) {
      fetchCourseDetails();
      fetchLessons();
      fetchProgress();
    }
  }, [courseId]);

  const fetchCourseDetails = async () => {
    try {
      const data = await courseAPI.getCourse(Number(courseId));
      // Map the Course type to CourseDetail by adding missing properties
      const courseDetail: CourseDetail = {
        ...data,
        description: data.description || '',
        category: data.category || '',
        lessons: data.lessons || [],
        total_lessons: data.total_lessons || 0
      };
      setCourse(courseDetail);
    } catch (error) {
      console.error('Failed to fetch course details:', error);
    }
  };

  const fetchLessons = async () => {
    try {
      const response = await fetch(`http://localhost:8000/courses/${courseId}/lessons`);
      const data = await response.json();
      setLessons(data);
    } catch (error) {
      console.error('Failed to fetch lessons:', error);
    }
  };

  const fetchProgress = async () => {
    try {
      const data = await courseAPI.getUserProgress();
      const courseProgress = data.find((p: any) => p.course_id === Number(courseId));
      setProgress(courseProgress);
    } catch (error) {
      console.error('Failed to fetch progress:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteLesson = async (lessonId: number) => {
    try {
      setCompletingLesson(lessonId);
      const response = await fetch(`http://localhost:8000/lessons/${lessonId}/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const result = await response.json();
        // Refresh data
        await fetchLessons();
        await fetchProgress();
        
        // Show success message
        alert(`Урок завершен! Получено ${result.points_earned} очков!`);
      }
    } catch (error) {
      console.error('Failed to complete lesson:', error);
    } finally {
      setCompletingLesson(null);
    }
  };

  const handleStartLesson = (lesson: Lesson) => {
    setLessonDialog(lesson);
  };

  const handleCloseLessonDialog = () => {
    setLessonDialog(null);
  };

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'success';
      case 'intermediate': return 'warning';
      case 'advanced': return 'error';
      default: return 'default';
    }
  };

  const getDifficultyText = (level: string) => {
    switch (level) {
      case 'beginner': return 'Начинающий';
      case 'intermediate': return 'Средний';
      case 'advanced': return 'Продвинутый';
      default: return level;
    }
  };

  const isLessonAvailable = (lesson: Lesson) => {
    if (lesson.order === 1) return true;
    const previousLesson = lessons.find(l => l.order === lesson.order - 1);
    return previousLesson?.is_completed || false;
  };

  const completedLessons = lessons.filter(l => l.is_completed).length;
  const progressPercentage = lessons.length > 0 ? (completedLessons / lessons.length) * 100 : 0;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress size={60} />
      </Box>
    );
  }

  if (!course) {
    return (
      <Box textAlign="center" py={8}>
        <Typography variant="h5" color="text.secondary">
          Курс не найден
        </Typography>
        <Button
          variant="contained"
          startIcon={<ArrowBack />}
          onClick={() => navigate('/courses')}
          sx={{ mt: 2 }}
        >
          Вернуться к курсам
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box display="flex" alignItems="center" mb={3}>
        <IconButton onClick={() => navigate('/courses')} sx={{ mr: 2 }}>
          <ArrowBack />
        </IconButton>
        <Typography variant="h4" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
          {course.title}
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Course Overview */}
        <Grid item xs={12} md={4}>
          <Card sx={{ mb: 3 }}>
            {course.thumbnail_url && (
              <Box
                component="img"
                src={course.thumbnail_url}
                alt={course.title}
                sx={{
                  width: '100%',
                  height: 200,
                  objectFit: 'cover',
                }}
              />
            )}
            <CardContent>
              <Typography variant="h6" gutterBottom>
                О курсе
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                {course.description}
              </Typography>
              
              <Box display="flex" gap={1} mb={2}>
                <Chip
                  label={getDifficultyText(course.difficulty_level)}
                  color={getDifficultyColor(course.difficulty_level) as any}
                  size="small"
                />
                <Chip
                  label={course.category}
                  size="small"
                  variant="outlined"
                />
              </Box>

              <Box display="flex" alignItems="center" gap={2} mb={2}>
                <Box display="flex" alignItems="center">
                  <Schedule sx={{ mr: 0.5, fontSize: 16 }} />
                  <Typography variant="body2" color="text.secondary">
                    {course.duration_hours}ч
                  </Typography>
                </Box>
                <Box display="flex" alignItems="center">
                  <EmojiEvents sx={{ mr: 0.5, fontSize: 16 }} />
                  <Typography variant="body2" color="text.secondary">
                    {course.max_points} очков
                  </Typography>
                </Box>
              </Box>

              <Divider sx={{ my: 2 }} />

              <Box mb={2}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                  <Typography variant="body2" color="text.secondary">
                    Прогресс курса
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>
                    {Math.round(progressPercentage)}%
                  </Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={progressPercentage}
                  sx={{ 
                    height: 8,
                    borderRadius: 4,
                    backgroundColor: 'rgba(0,0,0,0.1)',
                    '& .MuiLinearProgress-bar': {
                      borderRadius: 4,
                    }
                  }}
                />
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                  {completedLessons} из {lessons.length} уроков завершено
                </Typography>
              </Box>

              {progress?.points_earned && (
                <Chip
                  icon={<TrendingUp />}
                  label={`${progress.points_earned} очков заработано`}
                  color="primary"
                  size="small"
                />
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Lessons List */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold' }}>
              Уроки курса
            </Typography>
            
            <List>
              {lessons.map((lesson, index) => {
                const isAvailable = isLessonAvailable(lesson);
                const isCompleted = lesson.is_completed;
                
                return (
                  <ListItem 
                    key={lesson.id}
                    sx={{
                      mb: 1,
                      border: '1px solid',
                      borderColor: isCompleted ? 'success.main' : isAvailable ? 'divider' : 'grey.300',
                      borderRadius: 2,
                      bgcolor: isCompleted ? 'success.50' : isAvailable ? 'background.paper' : 'grey.50',
                      opacity: isAvailable || isCompleted ? 1 : 0.6,
                    }}
                  >
                    <ListItemAvatar>
                      <Avatar
                        sx={{
                          bgcolor: isCompleted ? 'success.main' : isAvailable ? 'primary.main' : 'grey.400',
                        }}
                      >
                        {isCompleted ? (
                          <CheckCircle />
                        ) : isAvailable ? (
                          <PlayArrow />
                        ) : (
                          <Lock />
                        )}
                      </Avatar>
                    </ListItemAvatar>
                    
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center" gap={1}>
                          <Typography variant="h6" sx={{ fontWeight: 600 }}>
                            {lesson.order}. {lesson.title}
                          </Typography>
                          <Chip
                            label={`+${lesson.points} очков`}
                            size="small"
                            color="primary"
                            variant="outlined"
                          />
                        </Box>
                      }
                      secondary={
                        <Box>
                          <Typography variant="body2" color="text.secondary" paragraph>
                            {lesson.description}
                          </Typography>
                          <Box display="flex" alignItems="center" gap={1}>
                            <Schedule sx={{ fontSize: 16 }} />
                            <Typography variant="caption" color="text.secondary">
                              {lesson.duration_minutes} минут
                            </Typography>
                            {isCompleted && lesson.completed_at && (
                              <>
                                <Typography variant="caption" color="text.secondary">
                                  • Завершено {new Date(lesson.completed_at).toLocaleDateString()}
                                </Typography>
                              </>
                            )}
                          </Box>
                        </Box>
                      }
                    />
                    
                    <Box>
                      {isCompleted ? (
                        <Chip
                          label="Завершено"
                          color="success"
                          size="small"
                        />
                      ) : isAvailable ? (
                        <Button
                          variant="contained"
                          startIcon={<PlayArrow />}
                          onClick={() => handleStartLesson(lesson)}
                          disabled={completingLesson === lesson.id}
                        >
                          {completingLesson === lesson.id ? 'Загрузка...' : 'Начать'}
                        </Button>
                      ) : (
                        <Chip
                          label="Заблокировано"
                          color="default"
                          size="small"
                        />
                      )}
                    </Box>
                  </ListItem>
                );
              })}
            </List>
          </Paper>
        </Grid>
      </Grid>

      {/* Lesson Dialog */}
      <Dialog open={!!lessonDialog} onClose={handleCloseLessonDialog} maxWidth="md" fullWidth>
        {lessonDialog && (
          <>
            <DialogTitle>
              {lessonDialog.title}
            </DialogTitle>
            <DialogContent>
              <Typography variant="body1" paragraph>
                {lessonDialog.description}
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Продолжительность: {lessonDialog.duration_minutes} минут
              </Typography>
              <Typography variant="body2" color="text.secondary">
                За завершение урока вы получите {lessonDialog.points} очков.
              </Typography>
              
              {/* Здесь можно добавить видео-плеер или другой контент урока */}
              <Box 
                sx={{ 
                  mt: 3, 
                  p: 4, 
                  bgcolor: 'grey.100', 
                  borderRadius: 2, 
                  textAlign: 'center' 
                }}
              >
                <School sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                <Typography variant="h6" color="text.secondary">
                  Контент урока
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Здесь будет размещен материал урока: видео, текст, задания
                </Typography>
              </Box>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseLessonDialog}>
                Отмена
              </Button>
              <Button
                variant="contained"
                onClick={() => {
                  handleCompleteLesson(lessonDialog.id);
                  handleCloseLessonDialog();
                }}
                disabled={completingLesson === lessonDialog.id}
              >
                Завершить урок
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default CourseDetailPage;