import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  LinearProgress,
  Chip,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  IconButton,
  Button,
  Paper,
  Divider,
  Badge,
  CircularProgress,
} from '@mui/material';
import {
  TrendingUp,
  Flag,
  EmojiEvents,
  School,
  Timer,
  Star,
  LocalFireDepartment,
  Psychology,
  Notifications,
  CheckCircle,
  PlayCircle,
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { goalAPI, achievementAPI, progressAPI, userAPI, courseAPI } from '../services/api';
import { Goal, Achievement, Progress, Course } from '../types';
import DailyAchievements from '../components/DailyAchievements';
import RankingWidget from '../components/RankingWidget';
import ActivityCalendar from '../components/ActivityCalendar';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [userStats, setUserStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [goalsData, achievementsData, progressData, coursesData, statsData] = await Promise.all([
          goalAPI.getActiveGoals(),
          achievementAPI.getUserAchievements(),
          progressAPI.getUserProgress(),
          courseAPI.getCourses(),
          userAPI.getUserStats(),
        ]);

        setGoals(goalsData);
        setAchievements(achievementsData);
        setProgress(progressData);
        setCourses(coursesData);
        setUserStats(statsData);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const recentAchievements = achievements.filter(a => a.is_unlocked).slice(0, 3);
  const activeGoals = goals.filter(g => g.status === 'in_progress');

  // Вычисляем прогресс до следующего уровня
  const currentLevel = user?.level || 1;
  const currentLevelPoints = (currentLevel - 1) * 1000;
  const nextLevelPoints = currentLevel * 1000;
  const userPoints = user?.total_points || 0;
  
  // Защита от деления на ноль и корректный расчет процента
  const pointsInCurrentLevel = userPoints - currentLevelPoints;
  const pointsNeededForLevel = nextLevelPoints - currentLevelPoints;
  const levelProgress = pointsNeededForLevel > 0 
    ? Math.min(Math.max((pointsInCurrentLevel / pointsNeededForLevel) * 100, 0), 100)
    : 0;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Приветственный баннер */}
      <Paper 
        elevation={0} 
        sx={{ 
          p: 4, 
          mb: 4, 
          background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
          color: 'white',
          borderRadius: 3,
          position: 'relative',
          overflow: 'hidden',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: -50,
            right: -50,
            width: 200,
            height: 200,
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            zIndex: 0,
          },
          '&::after': {
            content: '""',
            position: 'absolute',
            bottom: -30,
            left: -30,
            width: 150,
            height: 150,
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.05)',
            zIndex: 0,
          },
        }}
      >
        <Box display="flex" justifyContent="space-between" alignItems="center" sx={{ position: 'relative', zIndex: 1 }}>
          <Box>
            <Typography variant="h3" gutterBottom sx={{ fontWeight: 700, textShadow: '2px 2px 4px rgba(0,0,0,0.2)' }}>
              Добро пожаловать, {user?.full_name}! 🎆
            </Typography>
            <Typography variant="h6" sx={{ opacity: 0.95, fontWeight: 400 }}>
              Продолжайте свой путь к знаниям и достижениям
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
              <Chip 
                label={`Уровень ${user?.level || 1}`} 
                sx={{ 
                  background: 'rgba(255, 255, 255, 0.2)', 
                  color: 'white', 
                  fontWeight: 600,
                  backdropFilter: 'blur(10px)'
                }} 
              />
              <Chip 
                label={`${user?.streak_days || 0} дней подряд`} 
                sx={{ 
                  background: 'rgba(255, 255, 255, 0.2)', 
                  color: 'white', 
                  fontWeight: 600,
                  backdropFilter: 'blur(10px)'
                }} 
              />
            </Box>
          </Box>
          <Box textAlign="center" sx={{ 
            background: 'rgba(255, 255, 255, 0.15)', 
            borderRadius: 3, 
            p: 3,
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.2)'
          }}>
            <Typography variant="h1" sx={{ fontWeight: 800, mb: 1, textShadow: '2px 2px 4px rgba(0,0,0,0.2)' }}>
              {user?.level || 1}
            </Typography>
            <Typography variant="body1" sx={{ opacity: 0.9, fontWeight: 500 }}>Уровень</Typography>
          </Box>
        </Box>
      </Paper>

      <Grid container spacing={3}>
        {/* Статистика пользователя */}
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            height: '100%', 
            background: 'linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%)',
            borderRadius: 3,
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-8px)',
              boxShadow: '0px 12px 30px rgba(255, 107, 107, 0.4)',
            },
          }}>
            <CardContent sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" color="white">
                <Avatar sx={{ 
                  bgcolor: 'rgba(255,255,255,0.25)', 
                  mr: 2,
                  width: 56,
                  height: 56,
                  boxShadow: '0px 4px 12px rgba(0,0,0,0.2)',
                }}>
                  <Star sx={{ fontSize: 28 }} />
                </Avatar>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 800, textShadow: '1px 1px 2px rgba(0,0,0,0.2)' }}>
                    {user?.total_points || 0}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.95, fontWeight: 500 }}>
                    Общие очки
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            height: '100%', 
            background: 'linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%)',
            borderRadius: 3,
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-8px)',
              boxShadow: '0px 12px 30px rgba(78, 205, 196, 0.4)',
            },
          }}>
            <CardContent sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" color="white">
                <Avatar sx={{ 
                  bgcolor: 'rgba(255,255,255,0.25)', 
                  mr: 2,
                  width: 56,
                  height: 56,
                  boxShadow: '0px 4px 12px rgba(0,0,0,0.2)',
                }}>
                  <LocalFireDepartment sx={{ fontSize: 28 }} />
                </Avatar>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 800, textShadow: '1px 1px 2px rgba(0,0,0,0.2)' }}>
                    {user?.streak_days || 0}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.95, fontWeight: 500 }}>
                    Дней подряд
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            height: '100%', 
            background: 'linear-gradient(135deg, #a8e6cf 0%, #7fcdcd 100%)',
            borderRadius: 3,
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-8px)',
              boxShadow: '0px 12px 30px rgba(168, 230, 207, 0.4)',
            },
          }}>
            <CardContent sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" color="white">
                <Avatar sx={{ 
                  bgcolor: 'rgba(255,255,255,0.25)', 
                  mr: 2,
                  width: 56,
                  height: 56,
                  boxShadow: '0px 4px 12px rgba(0,0,0,0.2)',
                }}>
                  <School sx={{ fontSize: 28 }} />
                </Avatar>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 800, textShadow: '1px 1px 2px rgba(0,0,0,0.2)' }}>
                    {userStats?.courses_enrolled || 0}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.95, fontWeight: 500 }}>
                    Курсов
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            height: '100%', 
            background: 'linear-gradient(135deg, #ffd93d 0%, #ff6b6b 100%)',
            borderRadius: 3,
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-8px)',
              boxShadow: '0px 12px 30px rgba(255, 217, 61, 0.4)',
            },
          }}>
            <CardContent sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" color="white">
                <Badge badgeContent={0} color="error">
                  <Avatar sx={{ 
                    bgcolor: 'rgba(255,255,255,0.25)', 
                    mr: 2,
                    width: 56,
                    height: 56,
                    boxShadow: '0px 4px 12px rgba(0,0,0,0.2)',
                  }}>
                    <EmojiEvents sx={{ fontSize: 28 }} />
                  </Avatar>
                </Badge>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 800, textShadow: '1px 1px 2px rgba(0,0,0,0.2)' }}>
                    {achievements.filter(a => a.is_unlocked).length}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.95, fontWeight: 500 }}>
                    Достижений
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Прогресс уровня */}
        <Grid item xs={12} md={6}>
          <Card sx={{ 
            borderRadius: 3,
            background: 'linear-gradient(135deg, #f8fafc 0%, #ffffff 100%)',
            border: '1px solid #e2e8f0',
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0px 8px 25px rgba(0, 0, 0, 0.1)',
            },
          }}>
            <CardContent sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" mb={2}>
                <Avatar sx={{ 
                  bgcolor: 'primary.main', 
                  mr: 2,
                  background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                }}>
                  <TrendingUp />
                </Avatar>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Прогресс до следующего уровня
                </Typography>
              </Box>
              <Box sx={{ mb: 3 }}>
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body2" color="text.secondary">
                    {userPoints} / {nextLevelPoints} очков
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main' }}>
                    {Math.round(levelProgress)}%
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={levelProgress} 
                  sx={{ 
                    height: 12, 
                    borderRadius: 6,
                    backgroundColor: '#e2e8f0',
                    '& .MuiLinearProgress-bar': {
                      background: 'linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%)',
                      borderRadius: 6,
                    },
                  }}
                />
              </Box>
              <Box sx={{ 
                p: 2, 
                borderRadius: 2, 
                background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
                border: '1px solid #bae6fd'
              }}>
                <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>
                  🎨 До уровня {currentLevel + 1} осталось <strong>{Math.max(nextLevelPoints - userPoints, 0)}</strong> очков
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Мотивационное сообщение */}
        <Grid item xs={12} md={6}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)', 
            color: 'white',
            borderRadius: 3,
            position: 'relative',
            overflow: 'hidden',
            transition: 'all 0.3s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0px 12px 30px rgba(99, 102, 241, 0.4)',
            },
            '&::before': {
              content: '""',
              position: 'absolute',
              top: -20,
              right: -20,
              width: 100,
              height: 100,
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.1)',
              zIndex: 0,
            },
          }}>
            <CardContent sx={{ p: 3, position: 'relative', zIndex: 1 }}>
              <Box display="flex" alignItems="center" mb={2}>
                <Avatar sx={{ 
                  bgcolor: 'rgba(255,255,255,0.2)', 
                  mr: 2,
                  backdropFilter: 'blur(10px)',
                }}>
                  <Psychology />
                </Avatar>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Мотивация дня
                </Typography>
              </Box>
              <Typography variant="body1" sx={{ lineHeight: 1.6 }}>
                {user?.streak_days && user.streak_days > 0 
                  ? `Отлично! Вы уже ${user.streak_days} дней подряд занимаетесь! Продолжайте в том же духе! 🔥`
                  : "Каждый день - это новая возможность стать лучше. Начните свой путь к успеху! 🚀"
                }
              </Typography>
              <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                <Chip 
                  size="small"
                  label="Мотивация"
                  sx={{ 
                    background: 'rgba(255, 255, 255, 0.2)', 
                    color: 'white', 
                    fontWeight: 500,
                    backdropFilter: 'blur(10px)'
                  }}
                />
                <Chip 
                  size="small"
                  label="Успех"
                  sx={{ 
                    background: 'rgba(255, 255, 255, 0.2)', 
                    color: 'white', 
                    fontWeight: 500,
                    backdropFilter: 'blur(10px)'
                  }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Активные цели */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <Flag sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6">
                  Активные цели
                </Typography>
              </Box>
              {activeGoals.length > 0 ? (
                <List>
                  {activeGoals.map((goal) => (
                    <ListItem key={goal.id} divider>
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: 'primary.main' }}>
                          <Flag />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={goal.title}
                        secondary={
                          <Box>
                            <LinearProgress
                              variant="determinate"
                              value={goal.progress_percentage}
                              sx={{ mb: 1, height: 6, borderRadius: 3 }}
                            />
                            <Typography variant="caption">
                              {goal.progress_percentage}% завершено • +{goal.points_reward} очков
                            </Typography>
                          </Box>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Box textAlign="center" py={4}>
                  <Flag sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                  <Typography color="textSecondary">
                    Нет активных целей
                  </Typography>
                  <Button variant="outlined" sx={{ mt: 2 }}>
                    Создать цель
                  </Button>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Последние достижения */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <EmojiEvents sx={{ mr: 1, color: 'warning.main' }} />
                <Typography variant="h6">
                  Последние достижения
                </Typography>
              </Box>
              {recentAchievements.length > 0 ? (
                <List>
                  {recentAchievements.map((achievement) => (
                    <ListItem key={achievement.id} divider>
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: 'warning.main' }}>
                          <EmojiEvents />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={achievement.name}
                        secondary={achievement.description}
                      />
                      <Chip
                        label={`+${achievement.points_reward}`}
                        color="primary"
                        size="small"
                      />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Box textAlign="center" py={4}>
                  <EmojiEvents sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                  <Typography color="textSecondary">
                    Пока нет достижений
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Начните обучение, чтобы получить первые достижения!
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Рекомендуемые курсы */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Рекомендуемые курсы
              </Typography>
              <Grid container spacing={2}>
                {courses.slice(0, 3).map((course) => (
                  <Grid item xs={12} md={4} key={course.id}>
                    <Card variant="outlined" sx={{ height: '100%' }}>
                      <CardContent>
                        <Box display="flex" alignItems="center" mb={2}>
                          <PlayCircle sx={{ mr: 1, color: 'primary.main' }} />
                          <Typography variant="h6">
                            {course.title}
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="textSecondary" paragraph>
                          {course.description}
                        </Typography>
                        <Box display="flex" justifyContent="space-between" alignItems="center">
                          <Chip 
                            label={course.difficulty_level} 
                            size="small" 
                            color="primary" 
                            variant="outlined"
                          />
                          <Typography variant="body2" color="primary">
                            {course.max_points} очков
                          </Typography>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Activity Calendar */}
      <Box sx={{ mt: 4 }}>
        <ActivityCalendar />
      </Box>

      {/* Daily Achievements and Ranking Section */}
      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} lg={8}>
          <DailyAchievements />
        </Grid>
        <Grid item xs={12} lg={4}>
          <RankingWidget />
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;