import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Avatar,
  Grid,
  Divider,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
} from '@mui/material';
import {
  Edit,
  Save,
  Cancel,
  Person,
  Email,
  Star,
  TrendingUp,
  LocalFireDepartment,
  School,
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { userAPI } from '../services/api';
import { UserUpdate } from '../types';

const Profile: React.FC = () => {
  const { user, updateUser } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState<UserUpdate>({
    full_name: user?.full_name || '',
    avatar_url: user?.avatar_url || '',
  });
  const [userStats, setUserStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (user) {
      setFormData({
        full_name: user.full_name,
        avatar_url: user.avatar_url || '',
      });
    }
    fetchUserStats();
  }, [user]);

  const fetchUserStats = async () => {
    try {
      const stats = await userAPI.getUserStats();
      setUserStats(stats);
    } catch (error) {
      console.error('Failed to fetch user stats:', error);
    }
  };

  const handleEdit = () => {
    setEditing(true);
    setError('');
    setSuccess('');
  };

  const handleCancel = () => {
    setEditing(false);
    setFormData({
      full_name: user?.full_name || '',
      avatar_url: user?.avatar_url || '',
    });
    setError('');
    setSuccess('');
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      setError('');
      
      const updatedUser = await userAPI.updateCurrentUser(formData);
      updateUser(updatedUser);
      
      setEditing(false);
      setSuccess('Профиль успешно обновлен!');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Ошибка обновления профиля');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  if (!user) {
    return <Box>Загрузка...</Box>;
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Профиль
      </Typography>

      <Grid container spacing={3}>
        {/* Основная информация */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                <Typography variant="h6">
                  Личная информация
                </Typography>
                {!editing ? (
                  <Button
                    variant="outlined"
                    startIcon={<Edit />}
                    onClick={handleEdit}
                  >
                    Редактировать
                  </Button>
                ) : (
                  <Box>
                    <Button
                      variant="outlined"
                      startIcon={<Cancel />}
                      onClick={handleCancel}
                      sx={{ mr: 1 }}
                    >
                      Отмена
                    </Button>
                    <Button
                      variant="contained"
                      startIcon={<Save />}
                      onClick={handleSave}
                      disabled={loading}
                    >
                      Сохранить
                    </Button>
                  </Box>
                )}
              </Box>

              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              {success && (
                <Alert severity="success" sx={{ mb: 2 }}>
                  {success}
                </Alert>
              )}

              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Полное имя"
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleChange}
                    disabled={!editing}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Email"
                    value={user.email}
                    disabled
                    helperText="Email нельзя изменить"
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="URL аватара"
                    name="avatar_url"
                    value={formData.avatar_url}
                    onChange={handleChange}
                    disabled={!editing}
                    helperText="Введите URL изображения для аватара"
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Аватар и основная статистика */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box textAlign="center" mb={3}>
                <Avatar
                  src={user.avatar_url}
                  sx={{ width: 100, height: 100, mx: 'auto', mb: 2 }}
                >
                  {user.full_name.charAt(0)}
                </Avatar>
                <Typography variant="h6">
                  {user.full_name}
                </Typography>
                <Typography color="text.secondary">
                  @{user.username}
                </Typography>
              </Box>

              <Divider sx={{ my: 2 }} />

              <Box mb={2}>
                <Box display="flex" alignItems="center" mb={1}>
                  <Star sx={{ mr: 1, color: 'warning.main' }} />
                  <Typography variant="body2" color="text.secondary">
                    Общие очки
                  </Typography>
                </Box>
                <Typography variant="h5" fontWeight="bold">
                  {user.total_points.toLocaleString()}
                </Typography>
              </Box>

              <Box mb={2}>
                <Box display="flex" alignItems="center" mb={1}>
                  <TrendingUp sx={{ mr: 1, color: 'primary.main' }} />
                  <Typography variant="body2" color="text.secondary">
                    Уровень
                  </Typography>
                </Box>
                <Typography variant="h5" fontWeight="bold">
                  {user.level}
                </Typography>
              </Box>

              <Box mb={2}>
                <Box display="flex" alignItems="center" mb={1}>
                  <LocalFireDepartment sx={{ mr: 1, color: 'error.main' }} />
                  <Typography variant="body2" color="text.secondary">
                    Серия дней
                  </Typography>
                </Box>
                <Typography variant="h5" fontWeight="bold">
                  {user.streak_days}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Дополнительная статистика */}
        {userStats && (
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Статистика обучения
                </Typography>
                
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6} md={3}>
                    <Box textAlign="center">
                      <School sx={{ fontSize: 40, color: 'success.main', mb: 1 }} />
                      <Typography variant="h4" fontWeight="bold">
                        {userStats.courses_enrolled || 0}
                      </Typography>
                      <Typography color="text.secondary">
                        Курсов записано
                      </Typography>
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12} sm={6} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        {userStats.goals_completed || 0}
                      </Typography>
                      <Typography color="text.secondary">
                        Целей завершено
                      </Typography>
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12} sm={6} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        {userStats.achievements_unlocked || 0}
                      </Typography>
                      <Typography color="text.secondary">
                        Достижений получено
                      </Typography>
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12} sm={6} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        {userStats.total_lessons_completed || 0}
                      </Typography>
                      <Typography color="text.secondary">
                        Уроков завершено
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default Profile;

