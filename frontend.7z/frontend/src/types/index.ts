// User types
export interface User {
  id: number;
  email: string;
  username: string;
  full_name: string;
  is_active: boolean;
  is_verified: boolean;
  created_at: string;
  last_login?: string;
  total_points: number;
  level: number;
  streak_days: number;
  avatar_url?: string;
}

export interface UserCreate {
  email: string;
  username: string;
  password: string;
  full_name: string;
}

export interface UserLogin {
  email: string;
  password: string;
}

export interface UserUpdate {
  full_name?: string;
  avatar_url?: string;
}

// Course types
export interface Course {
  id: number;
  title: string;
  description?: string;
  instructor_id: number;
  created_at: string;
  is_active: boolean;
  duration_hours: number;
  difficulty_level: string;
  category?: string;
  thumbnail_url?: string;
  max_points: number;
  completion_bonus: number;
  lessons?: Lesson[]; // Optional for when courses include lesson data
  total_lessons?: number; // Optional for when courses include lesson count
}

export interface Lesson {
  id: number;
  course_id: number;
  title: string;
  description: string;
  order: number;
  points: number;
  duration_minutes: number;
  is_completed?: boolean;
  completed_at?: string;
}

export interface CourseCreate {
  title: string;
  description?: string;
  duration_hours: number;
  difficulty_level: string;
  category?: string;
  thumbnail_url?: string;
  max_points: number;
  completion_bonus: number;
}

// Goal types
export interface Goal {
  id: number;
  user_id: number;
  course_id: number;
  title: string;
  description?: string;
  goal_type: 'daily' | 'weekly' | 'monthly' | 'custom';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  created_at: string;
  due_date?: string;
  completed_at?: string;
  target_value: number;
  current_value: number;
  progress_percentage: number;
  points_reward: number;
  is_achieved: boolean;
}

export interface GoalCreate {
  course_id: number;
  title: string;
  description?: string;
  goal_type: 'daily' | 'weekly' | 'monthly' | 'custom';
  due_date?: string;
  target_value: number;
  points_reward: number;
}

export interface GoalProgressUpdate {
  current_value: number;
}

// Achievement types
export interface Achievement {
  id: number;
  user_id?: number;
  achievement_id?: number;
  name: string;
  description: string;
  achievement_type?: 'streak' | 'points' | 'completion' | 'social' | 'special';
  icon_url?: string;
  required_value?: number;
  current_value?: number;
  is_unlocked: boolean;
  unlocked_at?: string;
  created_at?: string;
  points_reward: number;
  badge_url?: string;
  type?: string;
}

// Notification types
export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  type?: string; // For backward compatibility
  notification_type: 'goal_reminder' | 'achievement_unlocked' | 'streak_warning' | 'motivational' | 'course_update' | 'social';
  is_read: boolean;
  is_sent: boolean;
  created_at: string;
  read_at?: string;
  action_url?: string;
  icon_url?: string;
  priority: number;
}

// Progress types
export interface Progress {
  id: number;
  user_id: number;
  course_id: number;
  completion_percentage: number;
  lessons_completed: number;
  total_lessons: number;
  time_spent_minutes: number;
  last_activity: string;
  points_earned: number;
  streak_days: number;
  is_completed: boolean;
  completed_at?: string;
  created_at: string;
}

// Leaderboard types
export interface LeaderboardEntry {
  user_id: number;
  username: string;
  full_name: string;
  total_points: number;
  level: number;
  streak_days: number;
  completion_rate: number;
  rank: number;
  avatar_url?: string;
}

// Auth types
export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

