import axios from 'axios';
import { 
  User, UserCreate, UserLogin, UserUpdate, AuthResponse,
  Course, CourseCreate,
  Goal, GoalCreate, GoalProgressUpdate,
  Achievement,
  Notification,
  Progress,
  LeaderboardEntry
} from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error);
    
    // Проверяем ошибки соединения
    if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
      console.error('Network error - backend may not be running');
      return Promise.reject({
        response: {
          data: {
            detail: 'Ошибка соединения с сервером. Проверьте, что backend запущен.'
          }
        }
      });
    }
    
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      localStorage.removeItem('user');
      // Не перенаправляем автоматически, позволяем компоненту обработать ошибку
    }
    
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (userData: UserCreate): Promise<AuthResponse> =>
    api.post('/auth/register', userData).then(res => res.data),
  
  login: (loginData: UserLogin): Promise<AuthResponse> =>
    api.post('/auth/login', loginData).then(res => res.data),
};

// User API
export const userAPI = {
  getCurrentUser: (): Promise<User> =>
    api.get('/users/me').then(res => res.data),
  
  updateCurrentUser: (userData: UserUpdate): Promise<User> =>
    api.put('/users/me', userData).then(res => res.data),
  
  getUserStats: (): Promise<any> =>
    api.get('/users/me/stats').then(res => res.data),
  
  getUserRanking: (): Promise<any> =>
    api.get('/users/ranking').then(res => res.data),
};

// Course API
export const courseAPI = {
  getCourses: (): Promise<Course[]> =>
    api.get('/courses').then(res => res.data),
  
  getCourse: (id: number): Promise<Course> =>
    api.get(`/courses/${id}`).then(res => res.data),
  
  createCourse: (courseData: CourseCreate): Promise<Course> =>
    api.post('/courses', courseData).then(res => res.data),
  
  updateCourse: (id: number, courseData: Partial<CourseCreate>): Promise<Course> =>
    api.put(`/courses/${id}`, courseData).then(res => res.data),
  
  deleteCourse: (id: number): Promise<void> =>
    api.delete(`/courses/${id}`).then(res => res.data),
  
  enrollInCourse: (id: number): Promise<void> =>
    api.post(`/courses/${id}/enroll`).then(res => res.data),
  
  getUserProgress: (): Promise<Progress[]> =>
    api.get('/progress').then(res => res.data),
};

// Goal API
export const goalAPI = {
  createGoal: (goalData: GoalCreate): Promise<Goal> =>
    api.post('/goals', goalData).then(res => res.data),
  
  getUserGoals: (): Promise<Goal[]> =>
    api.get('/goals').then(res => res.data),
  
  getActiveGoals: (): Promise<Goal[]> =>
    api.get('/goals/active').then(res => res.data),
  
  updateGoal: (id: number, goalData: Partial<GoalCreate>): Promise<Goal> =>
    api.put(`/goals/${id}`, goalData).then(res => res.data),
  
  updateGoalProgress: (id: number, progressData: GoalProgressUpdate): Promise<Goal> =>
    api.put(`/goals/${id}/progress`, progressData).then(res => res.data),
  
  completeGoal: (id: number): Promise<Goal> =>
    api.post(`/goals/${id}/complete`).then(res => res.data),
  
  deleteGoal: (id: number): Promise<void> =>
    api.delete(`/goals/${id}`).then(res => res.data),
};

// Achievement API
export const achievementAPI = {
  getUserAchievements: (): Promise<Achievement[]> =>
    api.get('/achievements').then(res => res.data),
  
  getDailyAchievements: (): Promise<any[]> =>
    api.get('/achievements/daily').then(res => res.data),
  
  checkDailyAchievements: (): Promise<any> =>
    api.post('/achievements/check-daily').then(res => res.data),
};

// Notification API
export const notificationAPI = {
  getNotifications: (): Promise<Notification[]> =>
    api.get('/notifications').then(res => res.data),
  
  markAsRead: (id: number): Promise<void> =>
    api.put(`/notifications/${id}/read`).then(res => res.data),
  
  createMotivationalNotification: (type: string, data?: any): Promise<any> =>
    api.post('/notifications/motivational', { type, data }).then(res => res.data),
  
  getUserBehaviorPatterns: (): Promise<any> =>
    api.get('/users/behavior-patterns').then(res => res.data),
};

// Progress API
export const progressAPI = {
  getUserProgress: (): Promise<Progress[]> =>
    api.get('/progress').then(res => res.data),
};

// Leaderboard API
export const leaderboardAPI = {
  getLeaderboard: (courseId?: number, limit?: number): Promise<LeaderboardEntry[]> =>
    api.get('/leaderboard', { params: { course_id: courseId, limit } }).then(res => res.data),
};

export default api;

