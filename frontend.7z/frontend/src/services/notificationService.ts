export interface NotificationOptions {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  requireInteraction?: boolean;
  silent?: boolean;
}

class NotificationService {
  private permission: NotificationPermission = 'default';

  constructor() {
    this.initializePermission();
  }

  private async initializePermission(): Promise<void> {
    if ('Notification' in window) {
      this.permission = Notification.permission;
      
      if (this.permission === 'default') {
        this.permission = await Notification.requestPermission();
      }
    }
  }

  async requestPermission(): Promise<NotificationPermission> {
    if ('Notification' in window) {
      this.permission = await Notification.requestPermission();
      return this.permission;
    }
    return 'denied';
  }

  isSupported(): boolean {
    return 'Notification' in window;
  }

  canShowNotifications(): boolean {
    return this.isSupported() && this.permission === 'granted';
  }

  showNotification(options: NotificationOptions): Notification | null {
    if (!this.canShowNotifications()) {
      console.warn('Notifications not supported or permission denied');
      return null;
    }

    const notification = new Notification(options.title, {
      body: options.body,
      icon: options.icon || '/favicon.ico',
      badge: options.badge,
      tag: options.tag,
      requireInteraction: options.requireInteraction || false,
      silent: options.silent || false,
    });

    // Auto-close after 5 seconds unless requireInteraction is true
    if (!options.requireInteraction) {
      setTimeout(() => {
        notification.close();
      }, 5000);
    }

    return notification;
  }

  // Smart motivational notifications based on user behavior
  showMotivationalNotification(type: 'streak_reminder' | 'achievement_unlock' | 'goal_reminder' | 'daily_encouragement' | 'study_break', data?: any): void {
    const motivationalMessages = {
      streak_reminder: {
        title: '🔥 Не прерывай серию!',
        body: `У тебя уже ${data?.streakDays || 0} дней подряд! Продолжай в том же духе!`,
        icon: '🔥'
      },
      achievement_unlock: {
        title: '🏆 Новое достижение!',
        body: `Поздравляем! Ты разблокировал "${data?.achievementName}"`,
        icon: '🏆'
      },
      goal_reminder: {
        title: '🎯 Время для целей!',
        body: data?.hasActiveGoals 
          ? 'У тебя есть незавершенные цели. Время поработать над ними!'
          : 'Поставь себе новую цель и начни её достигать!',
        icon: '🎯'
      },
      daily_encouragement: {
        title: '💪 Ты можешь это сделать!',
        body: this.getRandomEncouragement(),
        icon: '💪'
      },
      study_break: {
        title: '☕ Время отдыха!',
        body: 'Ты отлично работаешь! Сделай небольшой перерыв и продолжай с новыми силами.',
        icon: '☕'
      }
    };

    const message = motivationalMessages[type];
    this.showNotification({
      title: message.title,
      body: message.body,
      tag: type,
      requireInteraction: type === 'achievement_unlock'
    });
  }

  private getRandomEncouragement(): string {
    const encouragements = [
      'Каждый шаг приближает тебя к цели!',
      'Ты на правильном пути к успеху!',
      'Твоя настойчивость обязательно принесет плоды!',
      'Сегодня отличный день для новых достижений!',
      'Ты становишься лучше с каждым днем!',
      'Продолжай двигаться вперед, ты справишься!',
      'Твой потенциал безграничен!',
      'Маленькие шаги ведут к большим результатам!',
      'Ты уже достиг многого, продолжай!',
      'Верь в себя - ты способен на большее!'
    ];
    
    return encouragements[Math.floor(Math.random() * encouragements.length)];
  }

  // Schedule smart notifications based on user behavior patterns
  scheduleSmartNotifications(): void {
    // Daily encouragement at 9 AM
    this.scheduleNotification('daily_encouragement', { hour: 9, minute: 0 });
    
    // Goal reminder at 6 PM
    this.scheduleNotification('goal_reminder', { hour: 18, minute: 0 });
    
    // Study break reminder (every 2 hours during study time)
    for (let hour = 10; hour <= 20; hour += 2) {
      this.scheduleNotification('study_break', { hour, minute: 0 });
    }
  }

  private scheduleNotification(type: string, time: { hour: number; minute: number }): void {
    const now = new Date();
    const scheduled = new Date();
    scheduled.setHours(time.hour, time.minute, 0, 0);
    
    // If the time has passed today, schedule for tomorrow
    if (scheduled.getTime() <= now.getTime()) {
      scheduled.setDate(scheduled.getDate() + 1);
    }
    
    const timeUntilNotification = scheduled.getTime() - now.getTime();
    
    setTimeout(() => {
      if (type === 'daily_encouragement') {
        this.showMotivationalNotification('daily_encouragement');
      } else if (type === 'goal_reminder') {
        // Here you could fetch user's goals and check if they have active ones
        this.showMotivationalNotification('goal_reminder', { hasActiveGoals: true });
      } else if (type === 'study_break') {
        this.showMotivationalNotification('study_break');
      }
      
      // Reschedule for next day
      this.scheduleNotification(type, time);
    }, timeUntilNotification);
  }

  // Initialize smart notifications when user logs in
  initializeForUser(): void {
    this.requestPermission().then((permission) => {
      if (permission === 'granted') {
        this.scheduleSmartNotifications();
        console.log('Smart notifications initialized');
      }
    });
  }
}

export const notificationService = new NotificationService();