import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserLogin, UserCreate } from '../types';
import { authAPI, userAPI } from '../services/api';
import { setAuthToken, setUser, getUser, removeAuthToken, removeUser, getAuthToken } from '../utils/auth';
import { notificationService } from '../services/notificationService';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (loginData: UserLogin) => Promise<void>;
  register: (userData: UserCreate) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUserState] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      const token = getAuthToken();
      if (token) {
        try {
          // Проверяем токен, получая текущего пользователя
          const currentUser = await userAPI.getCurrentUser();
          setUserState(currentUser);
          
          // Initialize notifications for existing authenticated user
          notificationService.initializeForUser();
        } catch (error) {
          // Token is invalid, clear storage
          removeAuthToken();
          removeUser();
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (loginData: UserLogin) => {
    try {
      console.log('Attempting login with:', { email: loginData.email });
      const response = await authAPI.login(loginData);
      console.log('Login successful:', response);
      setAuthToken(response.access_token);
      setUser(response.user);
      setUserState(response.user);
      
      // Initialize smart notifications for logged in user
      notificationService.initializeForUser();
    } catch (error: any) {
      console.error('Login error:', error);
      // Очищаем локальное хранилище при ошибке
      removeAuthToken();
      removeUser();
      throw error;
    }
  };

  const register = async (userData: UserCreate) => {
    try {
      console.log('Attempting registration with:', { email: userData.email, username: userData.username });
      const response = await authAPI.register(userData);
      console.log('Registration successful:', response);
      setAuthToken(response.access_token);
      setUser(response.user);
      setUserState(response.user);
      
      // Initialize smart notifications for new user
      notificationService.initializeForUser();
    } catch (error: any) {
      console.error('Registration error:', error);
      // Очищаем локальное хранилище при ошибке
      removeAuthToken();
      removeUser();
      throw error;
    }
  };

  const logout = () => {
    removeAuthToken();
    removeUser();
    setUserState(null);
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      setUserState(updatedUser);
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    login,
    register,
    logout,
    updateUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

